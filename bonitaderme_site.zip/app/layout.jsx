export const metadata = {title: "BonitaDerme Clinic Global"};
export default function RootLayout({ children }) {
  return (
    <html lang="pt-br">
      <body>{children}</body>
    </html>
  );
}
