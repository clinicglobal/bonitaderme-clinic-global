export default function Home(){
  return (<main><h1>BonitaDerme Clinic Global</h1><p>Site placeholder pronto para deploy.</p></main>);
}
